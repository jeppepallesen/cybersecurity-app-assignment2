import unittest
from datetime import date

from app import create_app, db
from app.models import Note, Task, User


class StudentNotesTests(unittest.TestCase):
    def setUp(self):
        self.app = create_app({
            "TESTING": True,
            "SECRET_KEY": "test-secret",
            "SQLALCHEMY_DATABASE_URI": "sqlite://",
            "WTF_CSRF_ENABLED": False,
            "SEED_DEMO_DATA": False,
        })
        self.context = self.app.app_context()
        self.context.push()
        self.client = self.app.test_client()
        self.alice = User(username="alice")
        self.alice.set_password("wonderland")
        self.bob = User(username="bob")
        self.bob.set_password("builder")
        db.session.add_all([self.alice, self.bob])
        db.session.flush()
        self.note = Note(user_id=self.alice.id, title="Private note", content="A fictional study detail.")
        self.bobs_note = Note(user_id=self.bob.id, title="Bob's note", content="Another fictional detail.")
        self.task = Task(user_id=self.alice.id, title="Read chapter", description="Chapter 2", due_date=date(2030, 1, 2))
        db.session.add_all([self.note, self.bobs_note, self.task])
        db.session.commit()

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.context.pop()

    def login(self, username="alice", password="wonderland"):
        return self.client.post("/login", data={"username": username, "password": password})

    def test_login_and_logout(self):
        response = self.login()
        self.assertEqual(response.status_code, 302)
        self.assertIn(b"alice", self.client.get("/").data)
        self.client.post("/logout")
        self.assertEqual(self.client.get("/").status_code, 302)

    def test_invalid_login_is_rejected(self):
        response = self.login(password="incorrect")
        self.assertIn(b"Check your username and password", response.data)

    def test_notes_are_private_and_search_is_scoped(self):
        self.login()
        response = self.client.get("/notes")
        self.assertIn(b"Private note", response.data)
        self.assertNotIn(b"Bob&#39;s note", response.data)
        response = self.client.get("/search?q=fictional")
        self.assertIn(b"Private note", response.data)
        self.assertNotIn(b"Bob&#39;s note", response.data)

    def test_user_cannot_edit_another_users_note(self):
        self.login()
        response = self.client.post(f"/notes/{self.bobs_note.id}/edit", data={"title": "Changed", "content": "Nope"})
        self.assertEqual(response.status_code, 404)
        db.session.refresh(self.bobs_note)
        self.assertEqual(self.bobs_note.title, "Bob's note")

    def test_note_and_task_creation(self):
        self.login()
        self.client.post("/notes/new", data={"title": "New note", "content": "A new thought"})
        self.client.post("/tasks/new", data={"title": "New task", "description": "Details", "due_date": "2030-02-03"})
        self.assertIsNotNone(Note.query.filter_by(user_id=self.alice.id, title="New note").first())
        task = Task.query.filter_by(user_id=self.alice.id, title="New task").first()
        self.assertIsNotNone(task)
        self.assertFalse(task.completed)

    def test_edit_complete_and_delete_records(self):
        self.login()
        response = self.client.post(
            f"/notes/{self.note.id}/edit",
            data={"title": "Updated note", "content": "Revised content"},
        )
        self.assertEqual(response.status_code, 302)
        db.session.refresh(self.note)
        self.assertEqual(self.note.title, "Updated note")

        response = self.client.post(
            f"/tasks/{self.task.id}/edit",
            data={"title": "Updated task", "description": "Done soon", "due_date": "2030-02-03", "completed": "on"},
        )
        self.assertEqual(response.status_code, 302)
        db.session.refresh(self.task)
        self.assertTrue(self.task.completed)
        self.assertEqual(self.task.title, "Updated task")

        self.client.post(f"/tasks/{self.task.id}/toggle")
        db.session.refresh(self.task)
        self.assertFalse(self.task.completed)
        self.client.post(f"/notes/{self.note.id}/delete")
        self.client.post(f"/tasks/{self.task.id}/delete")
        self.assertIsNone(db.session.get(Note, self.note.id))
        self.assertIsNone(db.session.get(Task, self.task.id))


if __name__ == "__main__":
    unittest.main()