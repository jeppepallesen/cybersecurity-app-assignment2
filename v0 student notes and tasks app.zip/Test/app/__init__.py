import os

from flask import Flask, g, redirect, request, session, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect

db = SQLAlchemy()
csrf = CSRFProtect()


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("SECRET_KEY", "local-development-key-change-me"),
        SQLALCHEMY_DATABASE_URI=os.environ.get(
            "DATABASE_URL", "postgresql+psycopg2://student:student@localhost:5432/student_notes"
        ),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        SEED_DEMO_DATA=os.environ.get("SEED_DEMO_DATA", "true").lower() == "true",
    )
    if test_config:
        app.config.update(test_config)

    db.init_app(app)
    csrf.init_app(app)

    from app.models import User
    from app.routes import main

    app.register_blueprint(main)

    @app.before_request
    def load_user():
        user_id = session.get("user_id")
        g.user = db.session.get(User, user_id) if user_id else None
        if user_id and g.user is None:
            session.clear()

    @app.before_request
    def require_login():
        if request.endpoint and request.endpoint not in {"main.login", "static"}:
            if g.get("user") is None:
                return redirect(url_for("main.login"))

    with app.app_context():
        db.create_all()
        if app.config["SEED_DEMO_DATA"]:
            from app.seed import seed_demo_data

            seed_demo_data()

    return app