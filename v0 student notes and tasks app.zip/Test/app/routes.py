from datetime import date
from functools import wraps

from flask import Blueprint, abort, flash, g, redirect, render_template, request, session, url_for

from app import db
from app.models import Note, Task, User

main = Blueprint("main", __name__)


def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if g.user is None:
            return redirect(url_for("main.login"))
        return view(*args, **kwargs)

    return wrapped_view


def owned_record(model, record_id):
    record = model.query.filter_by(id=record_id, user_id=g.user.id).first()
    if record is None:
        abort(404)
    return record


@main.route("/login", methods=["GET", "POST"])
def login():
    if g.user is not None:
        return redirect(url_for("main.home"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user is None or not user.check_password(password):
            flash("Check your username and password, then try again.", "error")
        else:
            session.clear()
            session["user_id"] = user.id
            return redirect(url_for("main.home"))
    return render_template("login.html")


@main.post("/logout")
@login_required
def logout():
    session.clear()
    return redirect(url_for("main.login"))


@main.get("/")
@login_required
def home():
    notes = Note.query.filter_by(user_id=g.user.id).order_by(Note.created_at.desc()).limit(4).all()
    tasks = Task.query.filter_by(user_id=g.user.id).order_by(Task.completed, Task.due_date).limit(5).all()
    return render_template("home.html", notes=notes, tasks=tasks)


@main.get("/notes")
@login_required
def notes():
    items = Note.query.filter_by(user_id=g.user.id).order_by(Note.created_at.desc()).all()
    return render_template("notes.html", notes=items)


@main.route("/notes/new", methods=["GET", "POST"])
@login_required
def create_note():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        if not title:
            flash("A title is required.", "error")
        else:
            note = Note(user_id=g.user.id, title=title[:160], content=request.form.get("content", "").strip())
            db.session.add(note)
            db.session.commit()
            flash("Note created.", "success")
            return redirect(url_for("main.notes"))
    return render_template("note_form.html", note=None)


@main.route("/notes/<int:note_id>/edit", methods=["GET", "POST"])
@login_required
def edit_note(note_id):
    note = owned_record(Note, note_id)
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        if not title:
            flash("A title is required.", "error")
        else:
            note.title = title[:160]
            note.content = request.form.get("content", "").strip()
            db.session.commit()
            flash("Note updated.", "success")
            return redirect(url_for("main.notes"))
    return render_template("note_form.html", note=note)


@main.post("/notes/<int:note_id>/delete")
@login_required
def delete_note(note_id):
    db.session.delete(owned_record(Note, note_id))
    db.session.commit()
    flash("Note deleted.", "success")
    return redirect(url_for("main.notes"))


@main.get("/tasks")
@login_required
def tasks():
    items = Task.query.filter_by(user_id=g.user.id).order_by(Task.completed, Task.due_date).all()
    return render_template("tasks.html", tasks=items)


@main.route("/tasks/new", methods=["GET", "POST"])
@login_required
def create_task():
    if request.method == "POST":
        task = task_from_form()
        if task:
            task.user_id = g.user.id
            db.session.add(task)
            db.session.commit()
            flash("Task created.", "success")
            return redirect(url_for("main.tasks"))
    return render_template("task_form.html", task=None)


@main.route("/tasks/<int:task_id>/edit", methods=["GET", "POST"])
@login_required
def edit_task(task_id):
    task = owned_record(Task, task_id)
    if request.method == "POST":
        updated = task_from_form()
        if updated:
            task.title = updated.title
            task.description = updated.description
            task.due_date = updated.due_date
            task.completed = updated.completed
            db.session.commit()
            flash("Task updated.", "success")
            return redirect(url_for("main.tasks"))
    return render_template("task_form.html", task=task)


def task_from_form():
    title = request.form.get("title", "").strip()
    raw_due_date = request.form.get("due_date", "")
    try:
        due_date = date.fromisoformat(raw_due_date)
    except ValueError:
        due_date = None
    if not title or due_date is None:
        flash("A title and valid due date are required.", "error")
        return None
    return Task(
        title=title[:160],
        description=request.form.get("description", "").strip(),
        due_date=due_date,
        completed=request.form.get("completed") == "on",
    )


@main.post("/tasks/<int:task_id>/delete")
@login_required
def delete_task(task_id):
    db.session.delete(owned_record(Task, task_id))
    db.session.commit()
    flash("Task deleted.", "success")
    return redirect(url_for("main.tasks"))


@main.post("/tasks/<int:task_id>/toggle")
@login_required
def toggle_task(task_id):
    task = owned_record(Task, task_id)
    task.completed = not task.completed
    db.session.commit()
    return redirect(request.referrer or url_for("main.tasks"))


@main.get("/search")
@login_required
def search():
    query = request.args.get("q", "").strip()
    results = []
    if query:
        pattern = f"%{query}%"
        results = Note.query.filter(
            Note.user_id == g.user.id,
            db.or_(Note.title.ilike(pattern), Note.content.ilike(pattern)),
        ).order_by(Note.created_at.desc()).all()
    return render_template("search.html", query=query, notes=results)