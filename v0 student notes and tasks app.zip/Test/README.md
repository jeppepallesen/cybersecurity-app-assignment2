# Student Notes and Tasks

A small Flask app for keeping personal study notes and a due-date task list. Each account can only access its own records. PostgreSQL stores user accounts, notes, and tasks; passwords are stored as Werkzeug hashes.

## Run with Docker Compose

From this directory:

```sh
docker compose up --build
```

Open <http://localhost:5000>. The first database startup creates the schema, and the app adds fictional sample content for both demo users.

| Username | Password |
| --- | --- |
| alice | alice123 |
| bob | bob123 |

The Compose database uses a named volume. To remove the database and all stored data, run `docker compose down -v`.

## Run locally

Python 3.10+ and a running PostgreSQL server are required.

1. Create a PostgreSQL database and role, or use the Compose `db` service.
2. Create and activate a virtual environment, then install dependencies:

   ```sh
   python -m venv .venv
   # Windows PowerShell: .venv\Scripts\Activate.ps1
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   ```

3. Set `DATABASE_URL` to a PostgreSQL SQLAlchemy URL, for example `postgresql+psycopg2://student:student@localhost:5432/student_notes`. Set `SECRET_KEY` to a private random value outside local development.
4. Start the app:

   ```sh
   flask --app wsgi:app run --debug
   ```

The app creates any missing tables on startup. `schema.sql` is also mounted into the PostgreSQL image as its initialization schema. To disable demo users, set `SEED_DEMO_DATA=false`.

## Tests

Install the requirements and run `python -m unittest discover -s tests`. Tests use an in-memory SQLite database; the application itself defaults to PostgreSQL.

## Project layout

- `app/models.py`: SQLAlchemy user, note, and task models
- `app/routes.py`: authentication, home, CRUD, task completion, and note search
- `app/templates/`: Jinja pages and shared navigation
- `app/static/`: application styles and small client-side enhancements
- `schema.sql`: PostgreSQL tables and user-record relationships
- `docker-compose.yml`: web and PostgreSQL services